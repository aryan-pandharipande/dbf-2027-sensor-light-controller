EESchema Schematic File Version 4
LIBS:sensor_light_controller-cache
EELAYER 29 0
EELAYER END
$Descr A4 11693 8268
Sheet 1 1
Title "DBF 2027 Towed Sensor Light Controller"
Date "2026-09-23"
Rev "1.0"
Comp "VJTI / DBF Sensor"
Comment1 "Schematic reconstructed from supplied PCB connectivity"
Comment2 "Three lights: FWD / CTR / AFT; common low-side switch"
Comment3 "Towline carries control signal; sensor battery powers PCB"
Comment4 "Open in KiCad and Save As .kicad_sch"
$EndDescr
Text Notes 900 900 0 100 ~ 20
DBF 2027 TOWED SENSOR LIGHT CONTROLLER
Text Notes 900 1100 0 60 ~ 12
This schematic reflects the NETS/PADS present in the supplied PCB file. It is a reconstruction, not a replacement for an ERC-verified source schematic.
$Comp
L Connector_Generic:Conn_01x02 J1
U 1 1 1
P 1300 1700
F 0 "J1" H 1218 1917 50  0000 C CNN
F 1 "BATT_IN" H 1218 1826 50 0000 C CNN
	1    1300 1700
	-1 0 0 -1
$EndComp
$Comp
L Device:D_Schottky D1
U 1 1 2
P 2300 1700
F 0 "D1" H 2300 1484 50 0000 C CNN
F 1 "SS34" H 2300 1575 50 0000 C CNN
	1    2300 1700
	-1 0 0 1
$EndComp
$Comp
L Device:C C1
U 1 1 3
P 3100 2050
F 0 "C1" H 3215 2096 50 0000 L CNN
F 1 "10uF" H 3215 2005 50 0000 L CNN
	1    3100 2050
	1 0 0 -1
$EndComp
$Comp
L Regulator_Linear:AMS1117-3.3 U2
U 1 1 4
P 3900 1700
F 0 "U2" H 3900 1942 50 0000 C CNN
F 1 "AMS1117-3.3" H 3900 1851 50 0000 C CNN
	1    3900 1700
	1 0 0 -1
$EndComp
$Comp
L Device:C C2
U 1 1 5
P 4500 2050
F 0 "C2" H 4615 2096 50 0000 L CNN
F 1 "10uF" H 4615 2005 50 0000 L CNN
	1    4500 2050
	1 0 0 -1
$EndComp
$Comp
L Device:C C3
U 1 1 6
P 5100 2050
F 0 "C3" H 5215 2096 50 0000 L CNN
F 1 "100nF" H 5215 2005 50 0000 L CNN
	1    5100 2050
	1 0 0 -1
$EndComp
$Comp
L Connector_Generic:Conn_01x08 U1
U 1 1 7
P 6000 3000
F 0 "U1" H 6080 2992 50 0000 L CNN
F 1 "ATtiny13A-SSU" H 6080 2901 50 0000 L CNN
	1    6000 3000
	1 0 0 -1
$EndComp
$Comp
L Connector_Generic:Conn_01x02 J2
U 1 1 8
P 1300 3500
F 0 "J2" H 1218 3717 50 0000 C CNN
F 1 "TOWLINE" H 1218 3626 50 0000 C CNN
	1    1300 3500
	-1 0 0 -1
$EndComp
$Comp
L Device:R R1
U 1 1 9
P 2300 3500
F 0 "R1" V 2093 3500 50 0000 C CNN
F 1 "1k" V 2184 3500 50 0000 C CNN
	1    2300 3500
	0 1 1 0
$EndComp
$Comp
L Device:D_Zener D2
U 1 1 10
P 3000 3900
F 0 "D2" V 2954 3980 50 0000 L CNN
F 1 "1N5231B 5.1V" V 3045 3980 50 0000 L CNN
	1    3000 3900
	0 1 1 0
$EndComp
$Comp
L Device:R R2
U 1 1 11
P 6850 3200
F 0 "R2" V 6643 3200 50 0000 C CNN
F 1 "220" V 6734 3200 50 0000 C CNN
	1    6850 3200
	0 1 1 0
$EndComp
$Comp
L Transistor_FET:AO3400A Q1
U 1 1 12
P 7700 3300
F 0 "Q1" H 7904 3346 50 0000 L CNN
F 1 "AO3400A" H 7904 3255 50 0000 L CNN
	1    7700 3300
	1 0 0 -1
$EndComp
$Comp
L Device:R R3
U 1 1 13
P 7300 3900
F 0 "R3" H 7370 3946 50 0000 L CNN
F 1 "100k" H 7370 3855 50 0000 L CNN
	1    7300 3900
	1 0 0 -1
$EndComp
$Comp
L Connector_Generic:Conn_01x02 J3
U 1 1 14
P 9600 1700
F 0 "J3" H 9680 1692 50 0000 L CNN
F 1 "FWD" H 9680 1601 50 0000 L CNN
	1    9600 1700
	1 0 0 -1
$EndComp
$Comp
L Connector_Generic:Conn_01x02 J4
U 1 1 15
P 9600 2400
F 0 "J4" H 9680 2392 50 0000 L CNN
F 1 "CTR" H 9680 2301 50 0000 L CNN
	1    9600 2400
	1 0 0 -1
$EndComp
$Comp
L Connector_Generic:Conn_01x02 J5
U 1 1 16
P 9600 3100
F 0 "J5" H 9680 3092 50 0000 L CNN
F 1 "AFT" H 9680 3001 50 0000 L CNN
	1    9600 3100
	1 0 0 -1
$EndComp
Text Label 1650 1700 0 50 ~ 0
BATT_RAW
Text Label 2550 1700 0 50 ~ 0
VBAT
Text Label 4200 1700 0 50 ~ 0
3V3
Text Label 1700 3500 0 50 ~ 0
SIG_RAW
Text Label 2550 3500 0 50 ~ 0
PWM_IN
Text Label 6500 3200 2 50 ~ 0
LIGHT_EN
Text Label 7150 3200 2 50 ~ 0
GATE
Text Label 7900 3600 0 50 ~ 0
LED_RTN
Text Label 9100 1700 2 50 ~ 0
VBAT
Text Label 9100 1800 2 50 ~ 0
LED_RTN
Text Label 9100 2400 2 50 ~ 0
VBAT
Text Label 9100 2500 2 50 ~ 0
LED_RTN
Text Label 9100 3100 2 50 ~ 0
VBAT
Text Label 9100 3200 2 50 ~ 0
LED_RTN
Wire Wire Line
	1500 1700 2150 1700
Wire Wire Line
	2450 1700 3600 1700
Wire Wire Line
	3100 1900 3100 1700
Connection ~ 3100 1700
Wire Wire Line
	3100 2200 3100 2400
Wire Wire Line
	3900 2000 3900 2400
Wire Wire Line
	4500 1900 4500 1700
Wire Wire Line
	4500 2200 4500 2400
Wire Wire Line
	5100 1900 5100 1700
Wire Wire Line
	5100 2200 5100 2400
Wire Wire Line
	3600 1700 3600 1700
Wire Wire Line
	4200 1700 6000 1700
Wire Wire Line
	1500 1800 1500 2400
Wire Wire Line
	1500 2400 9000 2400
Wire Wire Line
	3100 2400 3900 2400
Connection ~ 3100 2400
Connection ~ 3900 2400
Connection ~ 4500 2400
Connection ~ 5100 2400
Wire Wire Line
	1500 3500 2150 3500
Wire Wire Line
	2450 3500 5800 3500
Wire Wire Line
	3000 3500 3000 3750
Wire Wire Line
	3000 4050 3000 4200
Wire Wire Line
	1500 3600 1500 4200
Wire Wire Line
	1500 4200 9000 4200
Connection ~ 3000 4200
Wire Wire Line
	5800 3200 6700 3200
Wire Wire Line
	7000 3200 7500 3200
Wire Wire Line
	7300 3200 7300 3750
Connection ~ 7300 3200
Wire Wire Line
	7300 4050 7300 4200
Wire Wire Line
	7900 3500 7900 4200
Connection ~ 7300 4200
Connection ~ 7900 4200
Wire Wire Line
	7900 3100 7900 1700
Wire Wire Line
	7900 1700 9400 1700
Wire Wire Line
	7900 2400 9400 2400
Wire Wire Line
	7900 3100 9400 3100
Wire Wire Line
	9000 1800 9000 4200
Wire Wire Line
	9000 2500 9000 4200
Wire Wire Line
	9000 3200 9000 4200
Text Notes 1050 1350 0 60 ~ 12
Sensor internal battery input
Text Notes 1050 3250 0 60 ~ 12
Aircraft towline signal input
Text Notes 5900 2550 0 60 ~ 12
U1: control logic / mode decoding
Text Notes 7400 2850 0 60 ~ 12
Q1: common low-side switch for all three light arrays
Text Notes 8800 1350 0 60 ~ 12
Separate physical light outputs: forward / center / aft
Text Notes 900 4700 0 55 ~ 0
PCB net relationships:
Text Notes 1050 4900 0 50 ~ 0
J1: BATT_RAW / GND   |   D1: BATT_RAW -> VBAT   |   U2: VBAT -> 3V3
Text Notes 1050 5050 0 50 ~ 0
J2: SIG_RAW / GND -> R1 -> PWM_IN   |   D2 clamps PWM_IN to GND
Text Notes 1050 5200 0 50 ~ 0
U1: 3V3, GND, PWM_IN, LIGHT_EN   |   R2: LIGHT_EN -> GATE   |   R3: GATE -> GND
Text Notes 1050 5350 0 50 ~ 0
J3/J4/J5: VBAT -> light array -> LED_RTN   |   Q1 switches LED_RTN
Text Notes 1050 5650 0 50 ~ 0
IMPORTANT: The supplied PCB contains an unassigned U1 pin 6 and uses the PCB's existing net assignments exactly.
Text Notes 1050 5800 0 50 ~ 0
This file is intended as a readable reconstructed schematic; perform ERC and electrical review before fabrication.
$EndSCHEMATC
