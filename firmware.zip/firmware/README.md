# Firmware

ATtiny13A firmware goes here. The chip is programmed over ISP (VCC, GND, RESET, MOSI, MISO, SCK), e.g. on a breadboard/socket before being soldered to the PCB.
